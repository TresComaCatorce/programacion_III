window.onload = function(){

    $('form').on('submit', function(e){
        //como tengo un form, debo evitar el comportamiento por default.
        e.preventDefault();  
    });

    $("#btnLogIn").click(function(e){;
        //lamar a login
    });

};

function login(){
    //preparo la data para enviar
    data = {
        "usuario": 
        "password":
    };
    $.ajax({
        url: "http://localhost:3000/login", 

        success: function(result,status,response){
           //si la peticion termina OK, guardo el token en session storage, y redirecciono a la pagina que viene en
           //el header "redirect".
                window.location.replace(response.getResponseHeader('redirect'));


            
        },
        error: function(jqXHR,textStatus,errorThrown ){
            console.log(errorThrown);
        },
        complete:function(jqXHR, textStatus){
            console.log(textStatus);
        }
    });
}