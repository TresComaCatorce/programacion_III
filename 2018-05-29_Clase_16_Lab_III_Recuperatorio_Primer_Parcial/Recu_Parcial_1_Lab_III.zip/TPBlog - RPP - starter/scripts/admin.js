var xhr;
var datos = new Array();
var postAModificar;

window.onload = function(){
    this.document.getElementById("btnGuardar").addEventListener("click",function(){

        guardar();
    });
    cargarDatos();

};

function guardar(){
           //modificacion o alta?
}

function enviarModificacion(data){
    //se puede moficiar a gusto.
    xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function(){
        if (this.readyState == 4 && this.status == 200) {
           var resp = this.response; 
           console.log(resp);
           cargarDatos();
           limpiarFormulario();
           postAModificar = null;
        }
    };
    xhr.open("POST","http://localhost:3000/modificar",true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.send(JSON.stringify(data));
}

function limpiarFormulario(){
    //limpia el formulario
}
function enviarAlta(data){
    $.ajax({

        headers:{
            'authorization' : //recuperar token del sessionStorage
        },
        
    });
}

function cargarDatos(){
    //cargar datos
    
}

function refrescarTabla(data){
    //refrescar tabla con la data del servidor. Mejorar si es posible.
    var tabla = this.document.getElementById("tblPosts");
    var nuevasFilas="";
    
    for(var i in data){
        nuevasFilas += "<tr>";
        nuevasFilas += "<td>" + data[i].id + "</td>";
        nuevasFilas += "<td>" + data[i].created_dttm + "</td>";
        nuevasFilas += "<td>" + data[i].titulo + "</td>";
        nuevasFilas += "<td>" + data[i].articulo + "</td>";
        //agregar el manejador del evento click a los botones
        nuevasFilas += "<td><input type='button' class ='btn btn-warning' value='Modificar' ></td>";
        nuevasFilas += "<td><input type='button' class ='btn btn-danger' value='Borrar' ></td>";
        nuevasFilas += "</tr>";
    }
    tabla.children[2].innerHTML = nuevasFilas;
}

function borrar(id){
//borrar
    
}


function modificar(id){
    //obtengo el post que hay que modificar
     
    
}