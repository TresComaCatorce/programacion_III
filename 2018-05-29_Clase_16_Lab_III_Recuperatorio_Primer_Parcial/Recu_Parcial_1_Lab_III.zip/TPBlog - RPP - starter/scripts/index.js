var xhr;
var datos = new Array();

function cargarDatos(){
//cargar datos
    
}

window.onload = function(){
    cargarDatos();
    
}


function cargarPosts(){
    //refrescar el DOM con los datos que volvieron del servidor. Usar columnas de bootstrap para que sea
    //responsive. Se deben mostrar 2 articulos por "row" en pantalla grande, por debajo de medium, se mostrar solo 1
    //usar el siguiente tag para la imagen: <img class='img-fluid' src="img/imagen_2.jpg" alt="Imagen puente de la torre">
    var posts = document.getElementsByTagName("main");
    posts[0].innerHTML = "";
    var post = "";

    //bucle comienzo




    //bucle fin

    posts[0].innerHTML = post;
    
}

